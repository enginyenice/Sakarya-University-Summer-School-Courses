#ifndef FileOperation
#define FileOperation
int GetLineCount();
void ReadFile(int N, int M, char lineData[N][M]);
void WriteFile(char *output);
void CreateOutputFile();
#endif